#!/bin/bash
set +e

AUTOSSH_CONF_PATH="/etc/ssh_tunnel"
AUTOSSH_LOGFILE="/var/log/ssh_tunnel/tunnel.log"
LOCAL_IP="0.0.0.0"
LOCAL_PORT="9550"
LOCAL_REMOTE_IP="127.0.0.1"
LOCAL_REMOTE_PORT="9550"
USER_CRED=""
REMOTE_SERVER=""
SSH_PORT=""

#PORT_KNOCK Function
PORT_KNOCK() {
     local remote_peer=$1

    #Check speciified remote addr
    if [[ -z "$remote_peer" ]]; then
	    echo "No FOUND remote peer" >> "$AUTOSSH_LOGFILE"
	    return 1
    fi

    #Tok-tok-tok to remote_peer
    nc -w 1 -z "$remote_peer" 1111
    nc -w 1 -z "$remote_peer" 3333
    nc -w 1 -z "$remote_peer" 4444
    sleep 2
}

#HELP FUNC
usage() {
    echo "Использование: $0 [опции]"
    echo ""
    echo "Опции:"
    echo "  -u, --user       Имя пользователя для SSH (обязательно)"
    echo "  -s, --server     IP удаленного сервера (обязательно)"
    echo "  -p, --dport     SSH порт удаленного сервера (обязательно)"
    echo "  -h, --help       Показать это сообщение"
    echo " "
    exit 1
}

while [ $# -gt 0 ]; do
    case "$1" in
        -u|--user)
	   USER_CRED="$2"
	   shift 2
	   ;;
        -s|--server)
            REMOTE_SERVER="$2"
            shift 2
            ;;
	-p|--dport)
	    SSH_PORT="$2"
	    shift 2
	    ;;
        -h|--help)
            usage
            ;;
        *)
            echo "Неизвестная опция: $1"
            usage
            ;;
    esac
done

#Check arguments. Three manatory arguments
[ -z "$USER_CRED" ] && { echo "Ошибка: не указано имя клиента" >> "$AUTOSSH_LOGFILE"; usage; }
[ -z "$REMOTE_SERVER" ] && { echo "Ошибка: сервер не указан" >> "$AUTOSSH_LOGFILE"; usage; }
[ -z "$SSH_PORT" ] && { echo "Ошибка: пор ssh не указан" >> "$AUTOSSH_LOGFILE"; usage; }

PORT_KNOCK "$REMOTE_SERVER"

#Check running tunnels via started process command string
PIDS=$(pgrep -f "$LOCAL_IP:$LOCAL_PORT" || true)
if [ -n "$PIDS" ]; then
    echo "$(date): Очистка старых процессов: $PIDS" >> "$AUTOSSH_LOGFILE"
    kill -9 $PIDS > /dev/null 2>&1 || true
fi


####Start tunnel

#Keeepalive arguments
SSH_ALIVE_OPTS="-o ServerAliveInterval=30 -o ServerAliveCountMax=3 -o StrictHostKeyChecking=no"

autossh -vv -M 0 -f -N \
    -i "$AUTOSSH_CONF_PATH/id_ssh_tunnel" \
    $SSH_ALIVE_OPTS \
    -L "$LOCAL_IP:$LOCAL_PORT:$LOCAL_REMOTE_IP:$LOCAL_REMOTE_PORT" \
    -p "$SSH_PORT" "$USER_CRED@$REMOTE_SERVER" >> "$AUTOSSH_LOGFILE" 2>&1

if [ $? -eq 0 ]; then
    echo "$(date): Команда запуска выполнена успешно" >> "$AUTOSSH_LOGFILE"
else
    echo "$(date): КРИТИЧЕСКАЯ ОШИБКА запуска туннеля" >> "$AUTOSSH_LOGFILE"
fi
